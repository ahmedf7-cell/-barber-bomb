#!/bin/sh
set -eu
: "${JWT_SECRET:?JWT_SECRET is missing}"
: "${ADMIN_PASSWORD_HASH:?ADMIN_PASSWORD_HASH is missing}"
if [ "${JWT_SECRET}" = "CHANGE_THIS_IN_PRODUCTION" ]; then
  echo "JWT_SECRET is still the placeholder"; exit 1
fi
echo "Production secrets are present."
