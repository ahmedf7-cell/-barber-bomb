Barber Bomb V9 — جاهز للنشر

1) انسخ server/.env.production.example إلى server/.env
2) ضع ADMIN_PASSWORD_HASH وJWT_SECRET وقيم WhatsApp الحقيقية.
3) شغّل:
   cd server
   docker compose up -d --build
4) افتح المنفذ 3000 خلف reverse proxy يدعم HTTPS.
5) اربط الدومين بالـreverse proxy.
6) اختبر:
   /api/health
   /login.html
   /index.html
7) اختبر حجزًا من هاتف، ثم أكّد الحجز من لوحة الإدارة.
8) فعّل WhatsApp webhook بعد وضع الدومين HTTPS.

مهم:
- لا ترفع .env إلى Git.
- لا تستخدم كلمة مرور الإدارة الافتراضية.
- استخدم HTTPS دائمًا في الإنتاج.
- SQLite مناسب كبداية على خادم واحد مع volume دائم؛ إذا توسع المشروع إلى عدة خوادم انقل قاعدة البيانات إلى PostgreSQL.
