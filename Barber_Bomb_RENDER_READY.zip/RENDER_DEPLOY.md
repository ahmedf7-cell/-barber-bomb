# Barber Bomb — Render Ready

هذا هو الإصدار الموحّد الجاهز للنشر.

## Render
- Root Directory: اتركه فارغًا
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/api/health`

## Environment Variables
ضع في Render:
- `JWT_SECRET` = قيمة طويلة وعشوائية
- `ADMIN_USER` = اسم مستخدم الإدارة
- `ADMIN_PASSWORD_HASH` = bcrypt hash لكلمة مرور الإدارة
- `DB_PATH` = `barber-bomb.sqlite` أو مسار تخزين دائم إذا توفر

لا ترفع ملف `.env` الحقيقي إلى GitHub.

## ملاحظة مهمة
النسخة السابقة كانت تضع الخادم داخل `server/` بينما Render كان يحاول الوصول إلى `/opt/render/project/src/server`، كما كانت بعض مسارات Express مكتوبة بترتيب غير صحيح. هذه النسخة تنقل ملفات التشغيل إلى جذر المشروع وتصحح المسارات.

كما تم ربط نموذج الحجز العام بقاعدة SQLite عبر API بدل تخزين الحجز في localStorage، حتى تظهر الحجوزات في لوحة الإدارة.

## Local
`npm install`
`npm start`

ثم افتح:
`http://localhost:3000`
