BARBER BOMB — REAL BOOKING BACKEND

Requirements:
- Node.js 20+
- npm

Run:
1. npm install
2. npm start
3. Open http://localhost:3000

The SQLite database file is created automatically as barber_bomb.db.

API:
GET  /api/barbers
GET  /api/services
GET  /api/slots?date=YYYY-MM-DD&barberId=1
POST /api/bookings
GET  /api/admin/bookings
DELETE /api/admin/bookings/:id

Important:
This is a real database-backed starter backend, but the admin endpoint is intentionally not public-ready:
before deployment, add authentication, HTTPS, rate limiting, input validation, backups, and proper admin authorization.
