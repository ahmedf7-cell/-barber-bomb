const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");
const app = express();
const db = new Database("barber_bomb.db");

db.exec(`
CREATE TABLE IF NOT EXISTS barbers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  name_el TEXT NOT NULL,
  price REAL NOT NULL DEFAULT 0,
  duration INTEGER NOT NULL DEFAULT 30,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  barber_id INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(barber_id,date,time)
);
`);

if (db.prepare("SELECT COUNT(*) c FROM barbers").get().c === 0) {
  const ins = db.prepare("INSERT INTO barbers(name) VALUES (?)");
  ["Barber 1","Barber 2","Barber 3"].forEach(x=>ins.run(x));
}
if (db.prepare("SELECT COUNT(*) c FROM services").get().c === 0) {
  const ins = db.prepare("INSERT INTO services(name_ar,name_en,name_el,price,duration) VALUES (?,?,?,?,?)");
  [
    ["قص شعر","Haircut","Κούρεμα",0,30],
    ["حلاقة وتحديد اللحية","Beard trim & shave","Περιποίηση γενειάδας",0,30],
    ["تنظيف بشرة","Facial cleansing","Καθαρισμός προσώπου",0,30],
    ["بروتين","Protein treatment","Protein",0,60],
    ["تحديد حواجب","Eyebrow shaping","Σχηματισμός φρυδιών",0,30]
  ].forEach(x=>ins.run(...x));
}

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

app.get("/api/barbers",(req,res)=>res.json(db.prepare("SELECT id,name FROM barbers WHERE active=1").all()));
app.get("/api/services",(req,res)=>res.json(db.prepare("SELECT id,name_ar,name_en,name_el,price,duration FROM services WHERE active=1").all()));

app.get("/api/slots",(req,res)=>{
  const {date,barberId}=req.query;
  if(!date || !barberId) return res.status(400).json({error:"date and barberId required"});
  const rows=db.prepare("SELECT time FROM bookings WHERE date=? AND barber_id=?").all(date,barberId);
  res.json({booked:rows.map(x=>x.time)});
});

app.post("/api/bookings",(req,res)=>{
  const {barberId,serviceId,date,time,name,phone}=req.body;
  if(!barberId||!serviceId||!date||!time||!name||!phone) return res.status(400).json({error:"بيانات ناقصة"});
  try {
    const info=db.prepare(`
      INSERT INTO bookings(barber_id,service_id,date,time,customer_name,phone)
      VALUES (?,?,?,?,?,?)
    `).run(barberId,serviceId,date,time,name.trim(),phone.trim());
    res.json({ok:true,id:info.lastInsertRowid});
  } catch(e) {
    if(String(e.message).includes("UNIQUE")) return res.status(409).json({error:"هذا الموعد تم حجزه للتو"});
    res.status(500).json({error:"حدث خطأ في الحجز"});
  }
});

app.get("/api/admin/bookings",(req,res)=>{
  const rows=db.prepare(`
    SELECT b.id,b.date,b.time,b.customer_name,b.phone,
           br.name barber,s.name_en service,s.price
    FROM bookings b
    JOIN barbers br ON br.id=b.barber_id
    JOIN services s ON s.id=b.service_id
    ORDER BY b.date,b.time
  `).all();
  res.json(rows);
});

app.delete("/api/admin/bookings/:id",(req,res)=>{
  db.prepare("DELETE FROM bookings WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.listen(3000,()=>console.log("BARBER BOMB running at http://localhost:3000"));
