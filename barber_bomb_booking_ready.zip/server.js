const express = require("express");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, "barber_bomb.db");
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const ADMIN_TOKEN = crypto.randomBytes(32).toString("hex");
const db = new Database(DB_PATH);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS barbers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  name_el TEXT NOT NULL,
  price REAL NOT NULL DEFAULT 0,
  duration INTEGER NOT NULL DEFAULT 30,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  barber_id INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(barber_id) REFERENCES barbers(id),
  FOREIGN KEY(service_id) REFERENCES services(id)
);
CREATE INDEX IF NOT EXISTS idx_bookings_barber_date ON bookings(barber_id,date);
`);

if (db.prepare("SELECT COUNT(*) c FROM barbers").get().c === 0) {
  const ins = db.prepare("INSERT INTO barbers(name) VALUES (?)");
  ["Barber 1", "Barber 2", "Barber 3"].forEach((x) => ins.run(x));
}
if (db.prepare("SELECT COUNT(*) c FROM services").get().c === 0) {
  const ins = db.prepare("INSERT INTO services(name_ar,name_en,name_el,price,duration) VALUES (?,?,?,?,?)");
  [
    ["قص شعر", "Haircut", "Κούρεμα", 0, 30],
    ["حلاقة وتحديد اللحية", "Beard trim & shave", "Περιποίηση γενειάδας", 0, 30],
    ["تنظيف بشرة", "Facial cleansing", "Καθαρισμός προσώπου", 0, 30],
    ["بروتين", "Protein treatment", "Protein", 0, 60],
    ["تحديد حواجب", "Eyebrow shaping", "Σχηματισμός φρυδιών", 0, 30]
  ].forEach((x) => ins.run(...x));
}

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

const OPEN_MINUTES = 9 * 60;
const CLOSE_MINUTES = 22 * 60;
const SLOT_STEP = 30;
const DAYS_OFF = new Set([0]); // Sunday

function isValidDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "")) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}
function toMinutes(hhmm) {
  const m = /^(\d{2}):(\d{2})$/.exec(String(hhmm || ""));
  if (!m) return NaN;
  const h = Number(m[1]), min = Number(m[2]);
  return h * 60 + min;
}
function overlaps(startA, durationA, startB, durationB) {
  return startA < startB + durationB && startB < startA + durationA;
}
function safeText(value, max = 120) {
  return String(value ?? "").trim().slice(0, max);
}
function requireAdmin(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!ADMIN_PASSWORD || token !== ADMIN_TOKEN) return res.status(401).json({ error: "غير مصرح" });
  next();
}
function bookingsFor(barberId, date) {
  return db.prepare(`
    SELECT b.id,b.time,s.duration
    FROM bookings b
    JOIN services s ON s.id=b.service_id
    WHERE b.barber_id=? AND b.date=?
    ORDER BY b.time
  `).all(barberId, date);
}

app.get("/health", (req, res) => res.json({ ok: true }));
app.get("/api/barbers", (req, res) => res.json(db.prepare("SELECT id,name FROM barbers WHERE active=1 ORDER BY id").all()));
app.get("/api/services", (req, res) => res.json(db.prepare("SELECT id,name_ar,name_en,name_el,price,duration FROM services WHERE active=1 ORDER BY id").all()));

app.get("/api/slots", (req, res) => {
  const { date, barberId, serviceId } = req.query;
  const bid = Number(barberId), sid = Number(serviceId);
  if (!isValidDate(date) || !Number.isInteger(bid) || !Number.isInteger(sid)) {
    return res.status(400).json({ error: "بيانات غير صحيحة" });
  }
  const service = db.prepare("SELECT duration FROM services WHERE id=? AND active=1").get(sid);
  const barber = db.prepare("SELECT id FROM barbers WHERE id=? AND active=1").get(bid);
  if (!service || !barber) return res.status(404).json({ error: "الحلاق أو الخدمة غير متاحة" });
  const day = new Date(`${date}T00:00:00`);
  if (Number.isNaN(day.getTime()) || DAYS_OFF.has(day.getDay())) return res.json({ booked: [], closed: true, slots: [] });

  const duration = Number(service.duration);
  const existing = bookingsFor(bid, date).map((x) => ({ start: toMinutes(x.time), duration: Number(x.duration) }));
  const slots = [];
  for (let m = OPEN_MINUTES; m + duration <= CLOSE_MINUTES; m += SLOT_STEP) {
    if (!existing.some((b) => overlaps(m, duration, b.start, b.duration))) slots.push(`${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`);
  }
  res.json({ booked: existing.map((x) => x.time), closed: false, slots });
});

app.post("/api/bookings", (req, res) => {
  const barberId = Number(req.body.barberId);
  const serviceId = Number(req.body.serviceId);
  const date = safeText(req.body.date, 10);
  const time = safeText(req.body.time, 5);
  const name = safeText(req.body.name, 80);
  const phone = safeText(req.body.phone, 30);

  if (!Number.isInteger(barberId) || !Number.isInteger(serviceId) || !isValidDate(date) || !/^\d{2}:\d{2}$/.test(time) || !name || !phone) {
    return res.status(400).json({ error: "بيانات ناقصة أو غير صحيحة" });
  }
  const barber = db.prepare("SELECT id FROM barbers WHERE id=? AND active=1").get(barberId);
  const service = db.prepare("SELECT id,duration FROM services WHERE id=? AND active=1").get(serviceId);
  if (!barber || !service) return res.status(400).json({ error: "الحلاق أو الخدمة غير متاحة" });

  const start = toMinutes(time), duration = Number(service.duration);
  const day = new Date(`${date}T00:00:00`);
  if (DAYS_OFF.has(day.getDay())) return res.status(400).json({ error: "المحل مغلق يوم الأحد" });
  if (start < OPEN_MINUTES || start + duration > CLOSE_MINUTES || start % SLOT_STEP !== 0) {
    return res.status(400).json({ error: "الوقت خارج ساعات العمل" });
  }
  const existing = bookingsFor(barberId, date);
  if (existing.some((x) => overlaps(start, duration, toMinutes(x.time), Number(x.duration)))) {
    return res.status(409).json({ error: "هذا الموعد غير متاح" });
  }

  try {
    const info = db.prepare(`INSERT INTO bookings(barber_id,service_id,date,time,customer_name,phone) VALUES (?,?,?,?,?,?)`)
      .run(barberId, serviceId, date, time, name, phone);
    res.json({ ok: true, id: info.lastInsertRowid });
  } catch (e) {
    res.status(500).json({ error: "حدث خطأ في الحجز" });
  }
});

app.post("/api/admin/login", (req, res) => {
  if (!ADMIN_PASSWORD) return res.status(503).json({ error: "ADMIN_PASSWORD غير مضبوط على الخادم" });
  if (String(req.body.password || "") !== ADMIN_PASSWORD) return res.status(401).json({ error: "كلمة المرور غير صحيحة" });
  res.json({ ok: true, token: ADMIN_TOKEN });
});

app.get("/api/admin/bookings", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT b.id,b.date,b.time,b.customer_name,b.phone,br.name barber,s.name_ar service,s.price,s.duration
    FROM bookings b JOIN barbers br ON br.id=b.barber_id JOIN services s ON s.id=b.service_id
    ORDER BY b.date,b.time,b.id
  `).all();
  res.json(rows);
});
app.delete("/api/admin/bookings/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM bookings WHERE id=?").run(Number(req.params.id));
  res.json({ ok: true });
});
app.get("/api/admin/barbers", requireAdmin, (req, res) => res.json(db.prepare("SELECT id,name,active FROM barbers ORDER BY id").all()));
app.post("/api/admin/barbers", requireAdmin, (req, res) => {
  const name = safeText(req.body.name, 80);
  if (!name) return res.status(400).json({ error: "اسم الحلاق مطلوب" });
  const info = db.prepare("INSERT INTO barbers(name) VALUES (?)").run(name);
  res.json({ id: info.lastInsertRowid, name, active: 1 });
});
app.patch("/api/admin/barbers/:id", requireAdmin, (req, res) => {
  const name = req.body.name == null ? null : safeText(req.body.name, 80);
  const active = req.body.active == null ? null : (req.body.active ? 1 : 0);
  db.prepare("UPDATE barbers SET name=COALESCE(?,name),active=COALESCE(?,active) WHERE id=?").run(name, active, Number(req.params.id));
  res.json({ ok: true });
});
app.get("/api/admin/services", requireAdmin, (req, res) => res.json(db.prepare("SELECT id,name_ar,name_en,name_el,price,duration,active FROM services ORDER BY id").all()));
app.patch("/api/admin/services/:id", requireAdmin, (req, res) => {
  const x = req.body;
  db.prepare(`UPDATE services SET name_ar=COALESCE(?,name_ar),name_en=COALESCE(?,name_en),name_el=COALESCE(?,name_el),price=COALESCE(?,price),duration=COALESCE(?,duration),active=COALESCE(?,active) WHERE id=?`)
    .run(x.name_ar == null ? null : safeText(x.name_ar, 100), x.name_en == null ? null : safeText(x.name_en, 100), x.name_el == null ? null : safeText(x.name_el, 100), x.price == null ? null : Math.max(0, Number(x.price)), x.duration == null ? null : Math.max(30, Number(x.duration)), x.active == null ? null : (x.active ? 1 : 0), Number(req.params.id));
  res.json({ ok: true });
});
app.get("/api/admin/settings", requireAdmin, (req, res) => res.json({ daysOff: ["Sunday"], hours: { open: "09:00", close: "22:00" }, slotMinutes: 30 }));

if (!ADMIN_PASSWORD) console.warn("WARNING: Set ADMIN_PASSWORD before production use.");
app.listen(PORT, () => console.log(`BARBER BOMB running on port ${PORT}`));
